const bloodGroup = ['A+', 'A-', 'AB+', 'AB-', 'B+', 'B-', 'O+', 'O-'];
const gender = ['Male', 'Female', 'Other'];
const religion = ['Muslims', 'Hindus', 'Buddhists', 'Christians', 'Others'];


export {
    bloodGroup,
    gender,
    religion
}



