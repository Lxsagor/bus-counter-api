import React from 'react'
import RequestForm from "../../components/Landing/Seeker/RequestForm";
import Seeker from "../../components/Landing/Seeker/Seekers";

const Seekers = () => {
    return(
        <>
            <RequestForm/>
            <Seeker/>
        </>
    )
}

export default Seekers
