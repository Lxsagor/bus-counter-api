import React from 'react'
import ShowProfile from "../../components/Landing/Profile/ShowProfile";


const Profile = () => {

    return (
        <>

            <ShowProfile/>


        </>
    )
}

export default Profile
