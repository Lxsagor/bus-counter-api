import React from "react";

const DriverDetails = () => {
    return <>Driver details</>;
};

export default DriverDetails;
