import React from "react";

const HelperDetails = () => {
    return <>Helper Details</>;
};

export default HelperDetails;
