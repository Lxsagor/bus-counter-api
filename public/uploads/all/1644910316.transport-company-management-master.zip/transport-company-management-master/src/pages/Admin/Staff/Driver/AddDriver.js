import React from "react";
import { Box, Button, Grid, TextField, Typography } from "@mui/material";
import { useStyles } from "../styled";

const AddDriver = () => {
    const classes = useStyles();
    return (
        <>
            <Box m={5}>
                <Typography variant="h6">Add Driver</Typography>
                <Box
                    mb={3}
                    sx={{
                        width: "42px",
                        height: "4px",
                        backgroundColor: "#33A551",
                    }}
                ></Box>
                <Box my={5}>
                    <Button variant="Text" component="label">
                        Upload Image
                        <input type="file" hidden />
                    </Button>
                </Box>
                <Grid container spacing={4}>
                    <Grid item lg={4} xs={12}>
                        <TextField
                            fullWidth
                            className={classes.field}
                            label="Driver's Name"
                        />
                    </Grid>
                    <Grid item lg={4} xs={12}>
                        <TextField
                            fullWidth
                            className={classes.field}
                            label="Address"
                        />
                    </Grid>
                    <Grid item lg={4} xs={12}>
                        <TextField
                            fullWidth
                            className={classes.field}
                            label="Phone Number"
                        />
                    </Grid>
                </Grid>
            </Box>
        </>
    );
};

export default AddDriver;
