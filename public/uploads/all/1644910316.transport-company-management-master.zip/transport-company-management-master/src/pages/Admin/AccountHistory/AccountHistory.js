import React from "react";

const AccountHistory = () => {
    return <div>AccountHistory</div>;
};

export default AccountHistory;
