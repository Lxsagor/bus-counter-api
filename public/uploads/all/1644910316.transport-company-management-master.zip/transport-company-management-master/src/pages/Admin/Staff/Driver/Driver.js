import React from "react";

const Driver = () => {
    return <>Driver list</>;
};

export default Driver;
