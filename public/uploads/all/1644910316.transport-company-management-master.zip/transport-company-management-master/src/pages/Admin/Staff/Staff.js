import React from "react";
import { Button, Grid, Typography } from "@mui/material";
import { Box } from "@mui/system";
import admin from "../../../assets/admin_dashboard_image/admin.png";
import driver from "../../../assets/admin_dashboard_image/driver.png";
import staff from "../../../assets/admin_dashboard_image/staff.png";
import Card from "../../../components/dashboard/DashboardCard";
import { Link } from "react-router-dom";
import IndexTable from "../../../components/Admin/Staff/IndexTable";

const Staff = () => {
    return (
        <>
            <Box m={5}>
                <Box mb={5}>
                    <Grid container spacing={2} alignItems="stretch">
                        <Grid item xs={12} lg={3}>
                            <Card
                                title={"Total Admins"}
                                number={7}
                                src={admin}
                            />
                        </Grid>
                        <Grid item xs={12} lg={3}>
                            <Card
                                title={"Total Drivers"}
                                number={14}
                                src={driver}
                            />
                        </Grid>
                        <Grid item xs={12} lg={3}>
                            <Card
                                title={"Total Staffs"}
                                number={15}
                                src={staff}
                            />
                        </Grid>
                    </Grid>
                </Box>

                <IndexTable />
            </Box>
        </>
    );
};

export default Staff;
