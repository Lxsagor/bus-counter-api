import React from 'react'

const Customize = () => {
    return (
        <div>
           Customize 
        </div>
    )
}

export default Customize
