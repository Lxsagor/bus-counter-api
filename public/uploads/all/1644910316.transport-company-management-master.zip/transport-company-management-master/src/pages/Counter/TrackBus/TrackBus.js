import React from "react";

const TrackBus = () => {
    return <div>Track Bus</div>;
};

export default TrackBus;
