import React from "react";

const Counters = () => {
    return <div>Counters</div>;
};

export default Counters;
