import { makeStyles } from "@mui/styles";
export const useStyles = makeStyles((theme) => ({
    card: {
        // minWidth: "337.91px",

        minHeight: "211.35px",
    },
    button: {
        borderRadius: "4.91506px",
        // minWidth: "286.3px",
        minHeight: "56.52px",
        textTransform: "capitalize !important",
    },
}));
