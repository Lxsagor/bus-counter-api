import React from "react";
import {
    AppBar,
    Avatar,
    Badge,
    Container,
    Grid,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Toolbar,
    Typography,
    IconButton,
} from "@mui/material";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import { useStyles } from "./styled";
import { deepOrange } from "@mui/material/colors";

import { Menu } from "@mui/icons-material";
import { useSelector } from "react-redux";

const SuperAdminHeader = ({ setDrawerOpen, drawerOpen }) => {
    const classes = useStyles();
    const { currentUser } = useSelector((state) => state.auth);

    return (
        <Grid container alignItems="center" justifyContent="space-between">
            <Grid item>
                <IconButton onClick={() => setDrawerOpen(!drawerOpen)}>
                    <Menu />
                </IconButton>
            </Grid>
            <Grid item>
                <List className={classes.list}>
                    <ListItem>
                        <Avatar sx={{ bgcolor: deepOrange[500] }}>A</Avatar>
                        <Typography variant="h6" m={3}>
                            {/* { currentUser && currentUser.name : "Admin"} */}
                            {currentUser ? currentUser.name : "Super Admin"}
                        </Typography>
                    </ListItem>
                </List>
            </Grid>
        </Grid>
    );
};

export default SuperAdminHeader;
